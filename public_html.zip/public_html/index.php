<?php
include('cfg.php');

$login_message = '';

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $email = $conn->real_escape_string($_POST['email']);
    $password = $_POST['password'];

    $query = "SELECT * FROM users WHERE email='$email' LIMIT 1";
    $result = $conn->query($query);

    if ($result && $result->num_rows > 0) {
	$user = $result->fetch_assoc();


        if (password_verify($password, $user['password_hash'])) {
            $_SESSION['user_id'] = $user['user_id'];
            $_SESSION['first_name'] = $user['first_name'];
            $_SESSION['last_name'] = $user['last_name'];
            $_SESSION['email'] = $user['email'];
            $login_message = "<p style='color:green;'>Logged in as {$user['first_name']} {$user['last_name']} ({$user['email']})</p>";
        } else {
            $login_message = "<p style='color:red;'>Invalid password.</p>";
        }
    } else {
        $login_message = "<p style='color:red;'>No account found with that email.</p>";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Login</title>
  <link rel="stylesheet" href="styles.css" />
</head>
<body>
  <div class="login-container">
    <h2>Login</h2>

    <?= $login_message ?>

    <?php if (empty($_SESSION['user_id'])): ?>
    <form action="index.php" method="POST">
      <label for="email">Email</label>
      <input type="email" id="email" name="email" placeholder="Enter your email" required>

      <label for="password">Password</label>
      <input type="password" id="password" name="password" placeholder="Enter your password" required>

      <button type="submit">Log In</button>
    </form>

    <div class="register-link">
      <p>Don't have an account? <a href="register.php">Register</a></p>
    </div>
    <?php else: ?>
      <p><a href="index.php">Logout</a></p>
    <?php endif; ?>
  </div>
</body>
</html>
