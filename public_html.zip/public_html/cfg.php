<?php
// cfg.php — clean JSON-safe DB connection
$DB_HOST = 'blue.cs.sonoma.edu';
$DB_USER = 'cs370_section2_backrowdevelopers';
$DB_PASS = 'srepolevedworkcab_007';
$DB_NAME = 'cs370_section2_backrowdevelopers';   // ✅ must be correct

// Try to connect
$conn = @new mysqli($DB_HOST, $DB_USER, $DB_PASS, $DB_NAME);

if ($conn->connect_errno) {
    // never echo HTML; return JSON and stop
    http_response_code(500);
    header('Content-Type: application/json');
    echo json_encode([
        'ok' => false,
        'message' => 'Database connection failed: ' . $conn->connect_error
    ]);
    exit;
}

$conn->set_charset('utf8mb4');

