<?php

include('cfg.php');
$login_message = '';

if ($_SERVER["REQUEST_METHOD"] === "POST") {
	try{
    		$first_name = $conn->real_escape_string($_POST['first_name']);
    		$last_name = $conn->real_escape_string($_POST['last_name']);
    		$email = $conn->real_escape_string($_POST['email']);
   		$password = password_hash($_POST['password'], PASSWORD_DEFAULT); 
  
		$sql = "INSERT INTO users (email, first_name, last_name, password_hash)
		       	VALUES ('$email', '$first_name', '$last_name', '$password')";
    		$conn->query($sql);
	}
	catch (Exception $e) {
		echo $e->getMessage();
	}
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Login</title>
  <link rel="stylesheet" href="styles.css" />
</head>
<body>
  <div class="login-container">
    <h2>Register</h2>
    <form action="register.php" method="POST">
      <label for="first_name">First Name</label>
      <input type="first_name" id="first_name" name="first_name" placeholder="Enter your first name" required>

      <label for="last_name">Last Name</label>
      <input type="last_name" id="last_name" name="last_name" placeholder="Enter your last name" required>
      
      <label for="email">Email</label>
      <input type="email" id="email" name="email" placeholder="Enter your email" required>

      <label for="password">Password</label>
      <input type="password" id="password" name="password" placeholder="Enter your password" required>

      <button type="submit">Create account</button>
    </form>
    <div class="register-link">
      <p>Already have an account? <a href="index.php">Login</a></p>
    </div>
  </div>
</body>
</html>
